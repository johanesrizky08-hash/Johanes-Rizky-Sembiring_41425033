/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pboweek2;

/**
 *
 * @author User
 */
public class hitung {
    void hitung() {
    int count = 0; // local variable
}
}
